import 'react-native-gesture-handler';
import * as React from 'react';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import Login from './components/Login';
import Painel from './components/Painel';
import Noticias1 from './components/Noticias1';
import Noticias2 from './components/Noticias2';
import Noticias3 from './components/Noticias3';
import Cadastro from './components/Cadastro';
import Listaperm from './components/Listaperm';
import Jogos from './components/Jogos';
import Horarios from './components/Horarios';
import Cardapio from './components/Cardapio';
import Menu from './components/Menu';

global.urlServidor = 'https://demo0748619.mockable.io/'; 
global.endPointLogin = 'login';
global.endPointDisciplinas = 'disciplinas';
global.disciplinaSelecionada = '';
global.imagensCapturadas = [];
global.classificacao = []; 
global.imagemSelecionada = '';
 
global.idtipo = 0;
global.opcao = '';

const Stack = createStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Menu"
        screenOptions={{
          headerStyle: { backgroundColor: '#800000' },
          headerTintColor: 'white',
          headerTitleStyle: { fontWeight: 'bold' },
        }}>
        <Stack.Screen
          name="Menu"
          component={Menu}
          options={{ title: 'Menu' }}
        />
        
        <Stack.Screen
          name="Painel"
          component={Painel}
          options={{ title: 'Painel de Notícias' }}
        />

        <Stack.Screen
          name="Noticias1"
          component={Noticias1}
          options={{ title: 'TVs em todas as salas!' }}
        />

        <Stack.Screen
          name="Noticias2"
          component={Noticias2}
          options={{ title: 'Conheça a ETEC League!' }}
        />

        <Stack.Screen
          name="Noticias3"
          component={Noticias3}
          options={{ title: 'Vestibulinho ETEC 2023' }}
        />

        <Stack.Screen
          name="Jogos"
          component={Jogos}
          options={{ title: 'Tabela Etec League' }}
        />

        <Stack.Screen
          name="Horarios"
          component={Horarios}
          options={{ title: 'Horarios' }}
        />

        <Stack.Screen
          name="Cardapio"
          component={Cardapio}
          options={{ title: 'Cardapio' }}
        />

        <Stack.Screen
          name="Login"
          component={Login}
          options={{ title: 'Login' }}
        />

        <Stack.Screen
          name="Cadastro"
          component={Cadastro}
          options={{ title: 'Cadastro' }}
        />

        <Stack.Screen
          name="Listaperm"
          component={Listaperm}
          options={{ title: 'Listaperm' }}
        />

        
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
