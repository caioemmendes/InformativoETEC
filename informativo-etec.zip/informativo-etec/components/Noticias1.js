import React, {Component, useState } from 'react';
import {FlatList, StyleSheet,View, Text, SafeAreaView, TouchableOpacity, Image } from 'react-native';


const Noticias3 = ({ route, navigation }) => {
  return ( 
    <SafeAreaView>
    <View>
      <Image  style={styles.imageIcon1}    
                    source={require('../assets/tvs.jpg')}                
                  />
    <Text style={{color:"black", padding:1, fontSize: 15,}}>
    <Text style={{color:"#ecf0f1"}}>.    </Text>
      As TVs são um grande marco para as escolas, pois ajudaram muito no aprendizado. Com as TVs os alunos conseguem ver melhor e prestar mais atenção nas aulas,
já que os slides são passados através da conexão da TV com o computador da sala.
      </Text>

      <Text style={{color:"black", padding:1, fontSize: 15,}}>
      <Text style={{color:"#ecf0f1"}}>.    </Text>
      E fazendo esse link, os professores conseguem passar vídeos e noticiários para os alunos
deixando as aulas muito mais práticas e produtivas, e ensino tende a melhorar após as TVs serem inseridas nas escolas.
      </Text>
    </View>
    </SafeAreaView>
  );
};

export default Noticias3;

const styles = StyleSheet.create({
  imageIcon1:{
    height: 180,
    width: 250, 
    borderColor: 'gray',
    borderRadius: 5,
    borderWidth:1,
    alignSelf:'center',
  },
});
