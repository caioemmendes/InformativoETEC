// React Native Bottom Navigation
// https://aboutreact.com/react-native-bottom-navigation/

import React, {Component, useState } from 'react';
import {FlatList, StyleSheet,View, Text, SafeAreaView, TouchableOpacity, Image } from 'react-native';

const Jogos = ({ route, navigation }) => {
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, padding: 16 }}>
      <Image  style={styles.stretchImage}    
                    source={require('../assets/tabelael.jpeg')}                
                  />

         <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Menu')}>
            <Text style={{color:"white", padding:1}}>Menu</Text>
          </TouchableOpacity>
      </View>

     
     
    </SafeAreaView>
  );
};

export default Jogos;
const styles = StyleSheet.create({
  button: {
    marginStart: 31,
    width: 250,
    height: 25,        
    borderWidth: 1,
    borderColor: 'black',
    marginBottom: 4,
    borderRadius: 8,
    backgroundColor: "#800000",
    alignItems: 'center',
  },

  stretchImage: {
      margin:50,
      resizeMode: 'contain',
      width: 300,
      height: 300,
      borderRadius: 80 / 5,
      alignSelf: 'center',
      position: "relative",
    },
  
});

