import React, {Component, useState } from 'react';
import {FlatList, StyleSheet,View, Text, SafeAreaView, TouchableOpacity, Image } from 'react-native';


const Noticias3 = ({ route, navigation }) => {
  return ( 
    <SafeAreaView>
    <View>
      <Image  style={styles.imageIcon1}    
                    source={require('../assets/etecvest.jpg')}                
                  />
    <Text style={{color:"black", padding:1, fontSize: 15,}}>
    <Text style={{color:"#ecf0f1"}}>.    </Text>
      As Escolas Técnicas Estaduais (Etecs) encerram nesta segunda, às 15h, as inscrições para mais de 1,7 mil vagas nas unidades do Vale do Paraíba e região.
      </Text>

      <Text style={{color:"black", padding:1, fontSize: 15,}}>
      <Text style={{color:"#ecf0f1"}}>.    </Text>
      Ao todo, são 1.760 vagas para os candidatos no Vale em diversos cursos como administração, nutrição, mecânica, desenvolvimento de sistemas, entre outros.
      </Text>

      <Text style={{color:"black", padding:1, fontSize: 15,}}>
      <Text style={{color:"#ecf0f1"}}>.    </Text>
      De acordo com o Centro Paula Souza, a taxa integral de inscrição é de R$ 39. Quem solicitou redução de 50% no valor deve aguardar o resultado do pedido para se inscrever.
      </Text>

      <Text style={{color:"black", padding:1, fontSize: 15,}}>
      <Text style={{color:"#ecf0f1"}}>.    </Text>
      A seleção dos candidatos volta a ser feita por meio de uma prova presencial. Por conta da pandemia, nos últimos dois anos o processo foi feito com base no histórico escolar dos estudantes.
      </Text>
    </View>
    </SafeAreaView>
  );
};

export default Noticias3;

const styles = StyleSheet.create({
  imageIcon1:{
    height: 170,
    width: 165, 
    borderColor: 'gray',
    borderRadius: 5,
    borderWidth:1,
    alignSelf:'center',
  },
});
