import React, { useState } from 'react';
import { Image, Alert, Button, TextInput, View, StyleSheet, TouchableOpacity, Text } from 'react-native';

const Login = ({ route, navigation }) => {  
  const [codigoetec,setcodigoetec]=useState("")
  const [password,setPassword]=useState("")
  const [RM,setRM]=useState("")

  const [timeOut, setTimeOut] = useState(20000);
  const [loading, setLoading] = useState(false);
  const [acess, setAcess] = useState(false);
  const [msg, setMsg] = useState('');
  
  
async function postLogin(){
    setLoading(true);

    var url = 'https://tccinformativoetec.000webhostapp.com/Login.php';

    var wasServerTimeout = false;
    var timeout = setTimeout(() => {
      wasServerTimeout = true;
      alert('Tempo de espera para busca de informações excedido');
    }, timeOut);

    
    const resposta = await fetch(url, {
      method: 'POST', //tipo de requisição
      body:JSON.stringify({
      codigoetec:codigoetec,
      RM:RM,
      password:password
      }),
      headers: {                
                'Content-Type': 'application/json',
              },
       
    })
      .then((response) => {
        timeout && clearTimeout(timeout);
        if (!wasServerTimeout) {
          return response.json();
        }
      })
      .then((responseJson) => {
        
        if(responseJson.informacoes){
          navigation.navigate('Menu')
        }else{
          alert('erro')
        }
        
        
      })
      //se ocorrer erro na requisição ou conversão
      .catch((error) => {
        console.log(error)
        timeout && clearTimeout(timeout);
      });

    setLoading(false);
  }



  return (      
      <View style={styles.container}>        
        <Text style={styles.paragraph}>
          INFORMATIVO ETEC
        </Text> 

        <TextInput
          value={codigoetec}
          onChangeText={(codigoetec) => setcodigoetec(codigoetec)}
          placeholder={'Código ETEC'}
          style={styles.input}
        />

        <TextInput
          value={RM}
          onChangeText={(RM) => setRM(RM)}
          placeholder={'RM'}
          style={styles.input}
        />
        
        <TextInput
          value={password}
          onChangeText={(password) => setPassword(password)}
          placeholder={'Senha'}
          secureTextEntry={true}
          style={styles.input}
        />

     


        <TouchableOpacity
              style={styles.button}
              //onPress={() => navigation.navigate('Pagina2')}>
              onPress={() => postLogin()}>
              
              <Text style={{color:"white", padding:10}}> Entrar </Text>
        </TouchableOpacity>

<TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Cadastro')}>
            <Text style={{color:"white", padding:10}}>Cadastrar</Text>
          </TouchableOpacity>
        
      </View>
    );
  }
export default Login;

const styles = StyleSheet.create({
  container: {
    flex: 11,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding:30,
  },

  input: {
    width: 250,
    height: 44,
    padding: 8,
    borderWidth: 1,
    borderColor: 'black',
    marginBottom: 10,
    borderRadius:8,
  },

  button: {
    width: "100%",
    height: 40,        
    borderWidth: 1,
    borderColor: 'black',
    marginBottom: 4,
    borderRadius: 8,
    backgroundColor: "#800000",
    alignItems: 'center',
  },


//style={styles.paragraph}

  paragraph: {
    //paddingLeft: "center",
    paddingTop: 70,
    height: 250,
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
