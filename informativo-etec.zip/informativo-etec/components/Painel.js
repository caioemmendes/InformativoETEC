// React Native Bottom Navigation
// https://aboutreact.com/react-native-bottom-navigation/

import React, {Component, useState } from 'react';
import {FlatList, StyleSheet,View, Text, SafeAreaView, TouchableOpacity, Image } from 'react-native';

global.colorIcon="#C0C0C0"

const Painel = ({ route, navigation }) => {
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, padding: 16 }}>
         <TouchableOpacity
            style={styles.buttonIcon}
            onPress={() => navigation.navigate('Noticias1')}>
            <Image  style={styles.imageIcon}    
                    source={require('../assets/etec.jpg')}                
                  />
            <Text style={{color:"black", padding:1, fontWeight: "bold", fontSize: 15, }}>Etec Recebe Novas TVs!</Text>
            <Text style={{color:"black", padding:1, fontSize: 15,}}>A Etec Ilza Nascimento Pintus recebeu novas TVs para melhor aprendizado dos alunos.</Text>
            
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.buttonIcon}
            onPress={() => navigation.navigate('Noticias2')}>
            <Image  style={styles.imageIcon}    
                    source={require('../assets/logoetecleague.jpg')}                
                  />
            <Text style={{color:"black", padding:1, fontWeight: "bold", fontSize: 15, }}>Entenda a ETEC LEAGUE</Text>
            <Text style={{color:"black", padding:1, fontSize: 15,}}>A Etec League é a maior diversão dos alunos durante o ano, entenda um pouco mais sobre.</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.buttonIcon}
            onPress={() => navigation.navigate('Noticias3')}>
            <Image  style={styles.imageIcon1}    
                    source={require('../assets/vestibulinho.jpg')}                
                  />
            <Text style={{color:"black", padding:1, fontWeight: "bold", fontSize: 15, }}>Inscrições Vestibulinho ETEC 2023 já estão abertas!!</Text>
            <Text style={{color:"black", padding:1, fontSize: 15,}}>Para mais informações clique na notícia!</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Menu')}>
            <Text style={{color:"white", padding:1}}>Menu</Text>
          </TouchableOpacity>
      </View>

     
     
    </SafeAreaView>
  );
};

export default Painel;
const styles = StyleSheet.create({
    imageIcon:{
    height: 100,
    width: 100, 
    borderRadius: 10,
    borderWidth:1,
    alignItems:'center',
  },

  imageIcon1:{
    height: 100,
    width: 100, 
    borderRadius: 10,
    borderWidth:1,
    alignItems:'center',
  },
  
  buttonIcon:{
	  alignItems: 'center',
		backgroundColor: global.colorIcon,
		borderRadius: 10,
		marginTop: 10,
		padding: 10,
    margin: 10,
  },

    button: {
    marginStart: 31,
    width: 250,
    height: 25,        
    borderWidth: 1,
    borderColor: 'white',
    marginBottom: 4,
    borderRadius: 8,
    backgroundColor: "#800000",
    alignItems: 'center',
  },
});

