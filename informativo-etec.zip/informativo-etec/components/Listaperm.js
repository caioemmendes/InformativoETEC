import React, { Component, useState, useEffect } from 'react';
import {
  ActivityIndicator,
  FlatList,
  StyleSheet,
  View,
  Text,
  SafeAreaView,
  TouchableOpacity,
  Image, ScrollView
} from 'react-native';



const Listaperm = ({ route, navigation }) => {
  const [listaInfo, setListaInfo] = useState([]);
  const [loading, setLoading] = useState(false);
  const [timeOut, setTimeOut] = useState(10000);
  const [viewLista, setViewLista] = useState(true);
  const [viewImage, setViewImage] = useState(true);
  const [selecionado, setSelecionado] = useState('');
  const [imagem_selecionada, setImagemSelecionada] = useState('');


  // armazena escola escolhida (idEscola e o nome)
  const clickItemFlatList = (item) => {
      global.idtipo=item.idtipo
      global.opcao=item.opcao
      alert("Escolha selecionada: "+item.tipousuario)
  };


  // executa a busca logo no início da execução
  useEffect(() => {
    getInformacoesBD();
  }, []);

  async function getInformacoesBD() {
    setLoading(true);
    var url = 'https://tccinformativoetec.000webhostapp.com/listaEscola.php';
    var wasServerTimeout = false;
    var timeout = setTimeout(() => {
      wasServerTimeout = true;
      setLoading(false);
      alert('Tempo de espera para busca de informações excedido');
    }, timeOut);

    const resposta = await fetch(url, {
      method: 'GET', //tipo de requisição
    })
      .then((response) => {
        timeout && clearTimeout(timeout); 
        if (!wasServerTimeout) {
          return response.json();
        }
      }) 
      .then((responseJson) => {
        setListaInfo([]);
        for (var i = 0; i < responseJson.tipousuario.length; i++) {
          setListaInfo((listaInfo) => {
            const list = [
              ...listaInfo,
              {
                idtipo: responseJson.tipousuario[i].idtipo,
                opcao: responseJson.tipousuario[i].opcao,
              },
            ];
            return list;
          });
        }
      })
      .catch((error) => {
        timeout && clearTimeout(timeout);
        if (!wasServerTimeout) {
          //Error logic here
        }

        //  alert('erro'+error)
      });

    setLoading(false);
  }
  return (
    <SafeAreaView style={{ flex: 11 }}>
      {viewLista ? (
        <View style={{ flex: 11 }}>
          {loading ? (
            <View style={{ flex: 11 }}>
              <Text
                style={{
                  fontSize: 15,
                  textAlign: 'center',
                  marginBottom: 16,
                  fontFamily: 'century gothic',
                }}>
                Aguarde obtendo informações
              </Text>
              <ActivityIndicator size="small" color="#0000ff" />
            </View>
          ) : (
            <Text style={styles.fontTexto}>
              Selecionar um Tipo
            </Text>
          )}
         
          <FlatList
            data={listaInfo}
            renderItem={({ item }) => (
               
              <View
                style={{
                        alignSelf: 'center',
                        borderBottomWidth: 1,
                        borderTopWidth: 1,
                        borderLeftWidth: 1,
                        borderRightWidth: 1,
                        borderRadius: 5,
                        backgroundColor: item.idtipo % 2 == 0 ? '@DCDCDC' : '#C0C0C0',
                        width:200,
                }
}>
                
                  <View style={{ padingLeft: 0 }}>
                    <TouchableOpacity onPress={() => clickItemFlatList(item)}>
                      <View>                        
                        <Text style={styles.fontTexto1}>Opção: {item.opcao} </Text>
                      </View>
                    </TouchableOpacity>
                  </View>
              </View>
              
            )}
          />
          
        </View>
      ) : (
        //<View alignItems="center">
         // <Text> Hino </Text>
         // <View style={{ padingLeft: 20, paddingRight: 20 }}>
          //  <Image
            //  style={styles.logotipo}
            //  source={{ uri: imagem_selecionada }}
           // />
        //  </View>
        //  <Text> {selecionado} </Text>
        <View>
          <TouchableOpacity
            style={{
              alignSelf: 'center',
              paddingRight: 5,
              width: 100,
              height: 20,
              borderRadius: 5,
              borderWidth: 1,
            }}
            onPress={() => setViewLista(true)}>
            <Text style={styles.button}>Voltar</Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
};

export default Listaperm;
const styles = StyleSheet.create({
  fontTexto: {
    marginBottom: 1,
    fontWeight: 'bold',
    fontSize: 16,
    fontFamily: 'century gothic',
    color: 'black',
    alignSelf: 'center',
  },

  fontTexto1: {
    marginBottom: 1,
    fontWeight: 'italic',
    fontSize: 12,
    borderRadius: 15,
    fontFamily: 'century gothic',
    color: 'black',
    alignSelf: 'center',
  },

  button: {
    width:250,
    height:40,        
    borderWidth: 1,
    borderColor: 'black',
    marginBottom: 4,
    borderRadius:8,
    backgroundColor: "#800000",
    alignSelf: 'center',
  },
});
