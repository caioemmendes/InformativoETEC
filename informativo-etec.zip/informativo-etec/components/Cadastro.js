import React, { useState } from 'react';
import { Image, Alert, Button, TextInput, View, StyleSheet, TouchableOpacity, Text, ActivityIndicator, ScrollView } from 'react-native';
import { StackActions } from '@react-navigation/native';
import * as SecureStore from 'expo-secure-store';
import Listaperm from './Listaperm';



const Cadastro = ({ route, navigation }) => {  
  const [id, setId] = useState(0);
  const [nome,setnome]=useState("")
  const [RG,setRG]=useState("")
  const [CPF,setCPF]=useState("")
  const [numero,setnumero]=useState("")
  const [datanasc,setdatanasc]=useState("")
  const [emailinst,setemailinst]=useState("")
  const [codigoetec,setcodigoetec]=useState("")
  const [password,setpassword]=useState("")
  const [RM,setRM]=useState("")
  const [timeOut, setTimeOut] = useState(20000);
  const [loading, setLoading] = useState(false);
  const [acess, setAcess] = useState(false);
  const [msg, setMsg] = useState('');
  const [viewListaperm, setViewListaperm] = useState(false);

  function visualizarListaperm(v) {
    setViewListaperm(v);
  }


  async function cadastrar() {
    if (global.idtipo == 0) {
      alert('Por favor, selecionar uma Escola!');
      return;
    }
    setLoading(true);
    var url = 'https://tccinformativoetec.000webhostapp.com/cadUsuario.php';

    var wasServerTimeout = false;
    var timeout = setTimeout(() => {
      wasServerTimeout = true;
      alert('Tempo de espera para busca de informações excedido');
    }, timeOut);

    const resposta = await fetch(url, {
      method: 'POST', //tipo de requisição
      body:JSON.stringify({
        nome:nome,
        RG:RG, 
        CPF:CPF,
        numero:numero, 
        datanasc:datanasc, 
        emailinst:emailinst, 
        codigoetec:codigoetec, 
        RM:RM, 
        password:password,
        idtipo: global.idtipo,
        }),
        headers: {                
                  'Content-Type': 'application/json',
                 },
       
    })
      .then((response) => {
        timeout && clearTimeout(timeout);
        if (!wasServerTimeout) {
          return response.json();
        }
      })
      .then((responseJson) => {
         alert(JSON.stringify(responseJson))
      })
      .catch((error) => {
        timeout && clearTimeout(timeout);
        if (!wasServerTimeout) {
//
          }
//
        });

      setLoading(false);
    }


async function consultar() {
    setLoading(true);
    var url = 'https://tccinformativoetec.000webhostapp.com/consUsuario.php';

    var wasServerTimeout = false;
    var timeout = setTimeout(() => {
      wasServerTimeout = true;
      alert('Tempo de espera para busca de informações excedido');
    }, timeOut);

    const resposta = await fetch(url, {
      method: 'POST', //tipo de requisição
      body: JSON.stringify({ CPF: CPF }),
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then((response) => {
        timeout && clearTimeout(timeout);
        if (!wasServerTimeout) {
          return response.json();
        }
      })
      .then((responseJson) => {
        if (responseJson.informacoes[0].id == 0)
          alert('Informação não econtrada!');
        else {
          setId(responseJson.informacoes[0].id);
          setnome(responseJson.informacoes[0].nome);
          setRG(responseJson.informacoes[0].RG);
          setnumero(responseJson.informacoes[0].numero);
          setdatanasc(responseJson.informacoes[0].datanasc);
          setemailinst(responseJson.informacoes[0].emailinst);
          setcodigoetec(responseJson.informacoes[0].codigoetec);
          setRM(responseJson.informacoes[0].RM);
          setpassword(responseJson.informacoes[0].password);

          global.opcao = responseJson.informacoes[0].opcao;
        }
      })
      //se ocorrer erro na requisição ou conversãok
      .catch((error) => {
        timeout && clearTimeout(timeout);
        if (!wasServerTimeout) {
          //Error logic here
        }

        //  alert('erro'+error)
      });

    setLoading(false);
  }



async function alterar() {
    setLoading(true);
    var url = 'https://tccinformativoetec.000webhostapp.com/altUsuario.php';

    var wasServerTimeout = false;
    var timeout = setTimeout(() => {
      wasServerTimeout = true;
      alert('Tempo de espera para busca de informações excedido');
    }, timeOut);

    const resposta = await fetch(url, {
      method: 'POST', //tipo de requisição
      body: JSON.stringify({
        id:id,
        nome: nome,
        RG: RG,
        CPF: CPF,
        numero: numero,
        datanasc: datanasc,
        emailinst: emailinst,
        codigoetec: codigoetec,
        RM: RM,
        password: password,
        idtipo: global.idtipo,
      }),
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then((response) => {
        timeout && clearTimeout(timeout);
        if (!wasServerTimeout) {
          return response.json();
        }
      })
      .then((responseJson) => {
        alert(JSON.stringify(responseJson));
      })
      //se ocorrer erro na requisição ou conversãok
      .catch((error) => {
        timeout && clearTimeout(timeout);
        if (!wasServerTimeout) {
          //Error logic here
        }

        //  alert('erro'+error)
      });

    setLoading(false);
  }


async function excluir() {
    if (id > 0) {
      setLoading(true);
      var url = 'https://tccinformativoetec.000webhostapp.com/excUsuario.php';

      var wasServerTimeout = false;
      var timeout = setTimeout(() => {
        wasServerTimeout = true;
        alert('Tempo de espera para busca de informações excedido');
      }, timeOut);

      const resposta = await fetch(url, {
        method: 'POST', //tipo de requisição
        body: JSON.stringify({
          id: id,
        }),
        headers: {
          'Content-Type': 'application/json',
        },
      })
        .then((response) => {
          timeout && clearTimeout(timeout);
          if (!wasServerTimeout) {
            return response.json();
          }
        })
        .then((responseJson) => {
          setId(0);
          setnome('');
          setRG('');
          setCPF('');
          setnumero('');
          setdatanasc('');
          setemailinst('');
          setcodigoetec('');
          setRM('');
          setpassword('');
          alert(JSON.stringify(responseJson));
        })
        //se ocorrer erro na requisição ou conversãok
        .catch((error) => {
          timeout && clearTimeout(timeout);
          if (!wasServerTimeout) {
            //Error logic here
          }

          //  alert('erro'+error)
        });

      setLoading(false);
    } else alert('Realizar consulta');
  }


return (      
      <View style={styles.container}>
      <ScrollView>
      {loading ? <ActivityIndicator size="small" color="#0000ff" /> : null}
      {!viewListaperm ? ( 
        <View>
       <Text style={styles.paragraph}>
          INFORMAÇÕES PESSOAIS
       </Text> 
        <Text>
          id{id}
        </Text>
        <TextInput
          value={nome}
          onChangeText={(text) => setnome(text)}
          placeholder={'Nome'}
          style={styles.input}
        />

        <TextInput
          value={RG}
          onChangeText={(text) => setRG(text)}
          placeholder={'RG'}
          style={styles.input}
        />

        <TextInput
          value={CPF}
          onChangeText={(text) => setCPF(text)}
          placeholder={'CPF'}
          style={styles.input}
        />

        <TextInput
          value={numero}
          onChangeText={(text) => setnumero(text)}
          placeholder={'Número'}
          style={styles.input}
        />

        <TextInput
          value={datanasc}
          onChangeText={(text) => setdatanasc(text)}
          placeholder={'Data de Nascimento'}
          style={styles.input}
        />

        <Text style={styles.paragraph}>
          INFORMAÇÕES ETEC
        </Text>

        <TextInput
          value={emailinst}
          onChangeText={(text) => setemailinst(text)}
          placeholder={'Email Institucional'}
          style={styles.input}
        />

        <TextInput
          value={codigoetec}
          onChangeText={(text) => setcodigoetec(text)}
          placeholder={'Código ETEC'}
          style={styles.input}
        />

        <TextInput
          value={RM}
          onChangeText={(text) => setRM(text)}
          placeholder={'RM'}
          style={styles.input}
        />

        <TextInput
          value={password}
          onChangeText={(text) => setpassword(text)}
          placeholder={'Password'}
          secureTextEntry={true}
          style={styles.input}
        />

        <Text>{msg}</Text>
        <Text>Tipo de usuario escolhido: {global.opcao}</Text>

          <TouchableOpacity
            style={styles.button}
            onPress={() => visualizarListaperm(true)}>
           <Text style={{color:"white", padding:10}}> Escolher </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.button}
            onPress={() => cadastrar()}>
            <Text style={{color:"white", padding:10}}>Cadastrar</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => consultar()}>
            <Text style={{color:"white", padding:10}}>Consultar</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => alterar()}>
            <Text style={{color:"white", padding:10}}>Alterar</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => excluir()}>
            <Text style={{color:"white", padding:10}}>Excluir</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Login')}>
            <Text style={{color:"white", padding:10}}>Login</Text>
          </TouchableOpacity>
          </View>
      ):( 
        <View
            style={{
              flex: 1.0,
              alignItems: 'center',
              padding: 50,
            }}>
            <Listaperm></Listaperm>
            <TouchableOpacity
              style={styles.button}
              onPress={() => visualizarListaperm(false)}>
              <Text style={{color:"white", padding:10}}>Voltar</Text>
            </TouchableOpacity>
          </View>
        )}
      

          </ScrollView>
      
          

          

      </View>
    );
  }
export default Cadastro;

const styles = StyleSheet.create({
  container: {
    flex: 11,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding:50,
  },

  input: {
    width: 250,
    height: 44,
    padding: 10,
    borderWidth: 1,
    borderColor: 'black',
    marginBottom: 10,
    borderRadius:8,
  },

  button: {
    width:250,
    height:40,        
    borderWidth: 1,
    borderColor: 'black',
    marginBottom: 4,
    borderRadius:8,
    backgroundColor: "#800000",
    alignItems: 'center',
  },

  paragraph: {
    paddingLeft: 2,
    paddingTop: -1,
    height: 25,
    fontSize: 12,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
