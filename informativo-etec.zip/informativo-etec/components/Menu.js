// React Native Bottom Navigation
// https://aboutreact.com/react-native-bottom-navigation/

import React, {Component, useState } from 'react';
import {FlatList, StyleSheet,View, Text, SafeAreaView, TouchableOpacity, Image } from 'react-native';

const Menu = ({ route, navigation }) => {
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, padding: 16 }}>
         <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Painel')}>
            <Text style={{color:"white", padding:1}}>Painel de Notícias</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Cardapio')}>
            <Text style={{color:"white", padding:1}}>Cardápio Semanal</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Horarios')}>
            <Text style={{color:"white", padding:1}}>Horários</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Jogos')}>
            <Text style={{color:"white", padding:1}}>Etec League</Text>
          </TouchableOpacity>
      </View>

     
     
    </SafeAreaView>
  );
};

export default Menu;
const styles = StyleSheet.create({
  button: {
    width: 250,
    height: 25,      
    marginBottom: 70,
    borderRadius: 8,
    backgroundColor: "#800000",
    alignSelf: 'center',
    alignItems: 'center',
  },
});

