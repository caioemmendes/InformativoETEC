import React, {Component, useState } from 'react';
import {FlatList, StyleSheet,View, Text, SafeAreaView, TouchableOpacity, Image } from 'react-native';


const Noticias3 = ({ route, navigation }) => {
  return ( 
    <SafeAreaView>
    <View>
      <Image  style={styles.imageIcon1}    
                    source={require('../assets/semifem.jfif')}                
                  /> 
      <Text style={{color:"black", padding:1, fontSize: 15,}}>
      <Text style={{color:"#ecf0f1"}}>.    </Text>
        A ETEC League é um evento anual que acontece na ETEC Ilza Nascimento Pintus. Os alunos competem durante o ano todo uma competição de pontos corridos e no final, 
um mata-mata contando com 4 times, no caso começa já nas semi-finais. Este ano em específico foi muito especial pois foi intriduzido o campeonato feminino, onde as meninas da nossa escola puderam montar times e participar da mesma dinâmica do campeonato. 
      </Text>

  <Image  style={styles.imageIcon1}    
                    source={require('../assets/semimasc.jfif')}                
                  />       
      <Text style={{color:"black", padding:1, fontSize: 15,}}>
      <Text style={{color:"#ecf0f1"}}>.    </Text>
        Atualmente estamos nos ultimos jogos das semi-finais, apenas esperando para ver quem enfrentará Slayers (Masculino), se será Inter de Vilão ou Losers, ambos masculinos. E
quem enfrentará Killer Queen (Feminino) nas finais, se será Inter de Vilãs ou Vasco da Cama, ambos femininos.
Você não perde por esperar esses confrontos para saber qual será a final do feminino e do masculino.
    </Text>
    </View>
    </SafeAreaView>
  );
};

export default Noticias3;

const styles = StyleSheet.create({
  imageIcon1:{
    height: 150,
    width: 150, 
    borderColor: 'gray',
    borderRadius: 5,
    borderWidth:1,
    alignSelf:'center',
  },
  imageIcon2:{
    height: 150,
    width: 150, 
    borderColor: 'gray',
    borderRadius: 5,
    borderWidth:1,
    alignSelf:'center',
  },
});
